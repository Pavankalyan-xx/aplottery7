import { useState } from "react";

export default function App() {
  const [page, setPage] = useState("home");
  const [role, setRole] = useState("user");

  const Nav = () => (
    <div style={{display:'flex',gap:10,padding:12,background:'#000',color:'#fff'}}>
      <button onClick={() => setPage("home")}>Home</button>
      <button onClick={() => setPage("games")}>Games</button>
      <button onClick={() => setPage("wallet")}>Wallet</button>
      <button onClick={() => setPage("support")}>Support</button>
      <button style={{marginLeft:'auto'}} onClick={() => { setRole(role === "user" ? "admin" : "user"); }}>
        Switch to {role === "user" ? "Admin" : "User"}
      </button>
    </div>
  );

  const Card = ({ title, children }) => (
    <div style={{background:'#111',color:'#fff',borderRadius:16,padding:16,boxShadow:'0 0 10px #000'}}>
      <h3>{title}</h3>
      {children}
    </div>
  );

  const Home = () => (
    <div style={{padding:20,display:'grid',gap:12}}>
      <Card title="aplottery7">
        <p>Play smart. Win big.</p>
        <div style={{display:'flex',gap:8}}>
          <button>Play Now</button>
          <button>Register</button>
        </div>
      </Card>
      <div style={{display:'grid',gap:12}}>
        <Card title="Wingo">1, 3, 5, 10 minute rounds</Card>
        <Card title="Aviator">Live multiplier demo</Card>
        <Card title="Casino">Slots • Dice • Roulette • Blackjack</Card>
      </div>
    </div>
  );

  const Games = () => (
    <div style={{padding:20,display:'grid',gap:12}}>
      <Card title="Wingo Demo"><p>Timer: 60s</p></Card>
      <Card title="Aviator Demo"><p>Multiplier: x1.23</p></Card>
      <Card title="Casino Demo"><p>Try demo games</p></Card>
    </div>
  );

  const Wallet = () => (
    <div style={{padding:20,display:'grid',gap:12}}>
      <Card title="Wallet Balance">₹0.00</Card>
      <Card title="Deposit / Withdraw">UPI • Bank • Wallet (Demo)</Card>
    </div>
  );

  const Support = () => (
    <div style={{padding:20}}>
      <Card title="Support">24/7 Demo Support Chat</Card>
    </div>
  );

  const Admin = () => (
    <div style={{padding:20,display:'grid',gap:12}}>
      <Card title="Admin Dashboard">Analytics (demo)</Card>
      <Card title="Users">Manage users</Card>
      <Card title="Transactions">Approve deposits/withdrawals</Card>
      <Card title="Games">Monitor demo games</Card>
      <Card title="Promotions">Bonuses & referrals</Card>
      <p style={{color:'#aaa'}}>Demo only. Real-money features require legal compliance.</p>
    </div>
  );

  const renderPage = () => {
    if (role === "admin") return <Admin />;
    if (page === "games") return <Games />;
    if (page === "wallet") return <Wallet />;
    if (page === "support") return <Support />;
    return <Home />;
  };

  return (
    <div style={{minHeight:'100vh',background:'#020617'}}>
      <Nav />
      {renderPage()}
    </div>
  );
}
